//screen variable
let gameScreen = "arcade";

//forest game storyline variables
let trees = [];
let tourguide; 
let foreststoryline; 
var message;
let timerWait = 0;
let timerButton1 = 0;
let timerButton2 = 0;
let timerButton3 = 0;

//forest game variables 
let character;
let characKey;
let platforms = [];

var forestTimer;
var forestscore = 0;
var startBX = 250; 
var startBY = 320;  
let ripples = []; //each ripple has x, y, length

// space variables
let asteroids = [];
let spaceShip;
let stars = [];
let planets;
let fire = [];
let titleFont;
let normalFont;
let guide;
let level;
let speechBubble = [];
let clown;
let messages;
let setCoordinates = [];
let clownCoordinates = [];
let characterCoordinates = [];
let collision = false;
let knife;
let next = false;
let portal;

//zombie variables
let zombiesRight = []
let zombiesLeft = []
let scoreNum = 0;
let timer = 20;
let timer2 = 100;
let score;
let windows = 'yellow'
let aBuilding;
let blood;
let homeButton;
let drawBuilings;
let chaseScene;
let arcadeFont;
let introFont;
let collisionZombies;
let nextButton;
let vector;
let song;
let amp;
let songButton;

function preload(){
  titleFont = loadFont("PressStart2P-Regular.ttf");
  normalFont = loadFont("Inconsolata-VariableFont_wdth,wght.ttf");
  arcadeFont = loadFont("ErbosDraco1StOpenNbpRegular-l5wX.ttf");
  introFont = loadFont("ShadowsIntoLight-Regular.ttf");
}



function setup() {
  createCanvas(900, 500);  
    //song
  //song = loadSound('SpaceGameMusic.mp3');
  song = loadSound("Falling Stars Night in Space Abstract Ambience.mp3");
  amp = new p5.Amplitude();
  
  //song button
  songButton = createButton("Sound");
  songButton.position(830, 10);
  songButton.mousePressed(play2);
  
  //maliha's variables 
  //forest game storyline variables 
  tourguide = new tourGuide();
  foreststoryline = new ForestStoryLine(); 
  for (var i = 0; i < 8; i++) {
    trees[i] = new TreeBg(0+i*120, 200, 20, 200); 
  }
  //forest game variables

  character = new MainCharacter();
  //display platforms
  for (var i = 0; i < 3; i++) {
    platforms[i] = new Platform(900-i*300, random(150, 300), 150, 30, color(144, 85, 202), 4);
  }

  //ripples
  for (let i = 0; i < 10; i++) {
		//create 10 ripples as shown above and store them in the array ripples
      ripples[i] = new p5.Vector((-1)*random(100, 1300), random(height-100, height), random(50, 150));  
	}  

  //sakshi's variables
  collisionZombies = new Collision();
  aBuilding = new ArcadeBuilding(330,400);
  blood = new Blood(100, 100);
  score = new Score(100, 100);
  knife = new Knife(50, 380);
  homeButton = new HomeButton(100, 100);
  drawBuildings = new DrawBuildings(100, 100);
  chaseScene = new Chase(100, 260);
  nextButton = new NextButton(500, 500);
  vector = new p5.Vector();
  
  for(let i = 0; i<20; i++){
  zombiesRight[i] = new Zombie (random(-500, width), random(30, 200), random(1, 3))
  }
  
    for(let i = 0; i<20; i++){
  zombiesLeft[i] = new Zombie2 (random(width+100, 150), random(30, 200), random(1, 3))
  }
  
  //my variables
  for (let i = 0; i<9; i++){
    asteroids[i] = new Asteroids();
  }
  
  spaceShip = new SpaceShip();
  
  for (let i = 0; i<1500; i++){
    stars[i] = new Stars();
  }
  planets = new Planets();
  guide = new tourGuide();
  for (let i = 0; i<4; i++){
    speechBubble[i] = new SpeechBubble(guide.position);
  }
  character = new MainCharacter();
  clown = new Clown(150, 300);
  clownCoordinates[0] = -20;
  clownCoordinates[2] = 450;
  clownCoordinates[3] = 70;
  setCoordinates[2] = 700;
  setCoordinates[3] = 220;
  setCoordinates[4] = 730;
  setCoordinates[5] = 360;
  setCoordinates[6] = 600;
  setCoordinates[7] = 220;
  characterCoordinates[0] = 300;
  characterCoordinates[1] = 275;
  characterCoordinates[2] = 420;
  characterCoordinates[3] = 365;
  
  portal = new Portal();
}

function draw() {
  //sound
  var vol = amp.getLevel();
  var diam = map(vol, 0, 0.3, 0, 255);

  if (gameScreen == "forestStoryline") {
    background(15, 54, 7);
  noStroke()
    for(let i = 0; i< trees.length; i++){
      trees[i].display();
    }

    //ground/water
    //fill(88, 167, 224);
    fill(116, 214, 180);
    rect(-5, 400, 910, 100);
  
  //show tourguide
  tourguide.display();
  
  //show text for storyline
  message = " \nYou have entered an enchanted forest. \nThe water has been poisoned by Krusty the clown. \nUse the arrow keys to avoid falling in the water.  \nYou have 30 seconds. \nGood luck!";
  fill(255, 255, 255, 200);
  rect(245, 100, 550, 210, 10);
  foreststoryline.bubble(message, 20, 270, 145); 
  
  //next button 
    stroke(0);
    strokeWeight(2);
    fill(255);
    if(mouseX>=770 && mouseX<=870 && mouseY>=420 && mouseY<=470) {
      fill(200); // click color
      if (mouseIsPressed){
        gameScreen = "forestGame";
      }
    }
    rect(770, 420, 100, 50);
    textSize(25);
    fill(0)
    text("Play", 795, 452); 
  }
  
  if (gameScreen == "forestGame"){
    timerWait++;
    background(15, 54, 7);
    strokeWeight(1);
    stroke(0);
  for(let i = 0; i< trees.length; i++){
    trees[i].display();
  }
    
  //ground/water
  fill(138, 208, 234);
  rect(-5, 400, 910, 100);
  //display platforms
  for(let i = 0; i< platforms.length; i++){
    platforms[i].display();
    if (timerWait>90){
    platforms[i].move();
    }
  //when character hits a platform
    if (character.intersects(platforms[i])) {
      character.onBlock(platforms[i]);
      if (frameCount%60==0 && forestTimer>0) { 
        forestscore++; 
      } 
    }
  }


    //starting platform
    startingBlock();
    startBX--; 

    
    //display character
    if (timerWait>90){
    character.gravity();
    }
    character.display();
    
    //timer
  textSize(30);
  fill(255);
  text("Timer: " +forestTimer, 710, 50);
  if (frameCount%60==0 && forestTimer>0) { 
    forestTimer--; 
  } 
    
  //game over
  character.gameover();
    
  if (forestTimer==0) {
    //game over
     character.gameover(); 
    
  }
    for (let i = 0; i < ripples.length; i++) {
	  //... see above
      drawRipple(ripples[i])
      ripples[i].x ++;
      if(ripples[i].x>width+80){
        ripples[i].x = (-1)*random(200, 800)
        ripples[i].y = random(width/2, height);
        ripples[i].z =  random(50, 150);
      }
    }  
    character.gameover()
    //noStroke()
  }
  
  if (gameScreen == "instructionsSpace"){
    background(0);
    timerButton2++;
    messages = "Oh no! You've been teleported to space! Use the arrow keys to avoid the asteroids. Once you reach Earth, you will be taken to the next level."
    for (let i = 0; i<stars.length; i++){
      stars[i].draw();
    }
    //spaceShip.position.x = 400;
    spaceShip.position.y = 220;
    spaceShip.drawSpaceShip();
    planets.display();
    guide.coordinates = setCoordinates;
    guide.displaySpace();
    speechBubble[0].coordinates = guide.coordinates;
    //guide.display();
    if (next == true){
      messages = "Good luck!";
      speechBubble[0].bubble(messages, 25, -232, -100)
      setCoordinates[2]-=4;
      setCoordinates[3]++;
      if (setCoordinates[2]<-60){
        gameScreen = "spaceGame";
      }
    }
    else{
      speechBubble[0].bubble(messages, 12, -232, -135);
    }
    fill(215, 180, 243);
    if(mouseX<870&&mouseX>770&&mouseY>420&&mouseY<470){
      fill(188, 154, 215)
      if (mouseIsPressed&&timerButton2>30){
        next = true;
        //gameScreen = "spaceGame";
      }
    }
    stroke(0);
    strokeWeight(3);
    rect(770, 420, 100, 50);
    textSize(25);
    fill(0)
    text("Play", 819, 452);
    characterCoordinates[0] = character.position.x;
    characterCoordinates[1] = character.position.y;
  }
  
  if (gameScreen=="spaceGame"){
    next = false;
    background(0);
    for (let i = 0; i<stars.length; i++){
      stars[i].draw();
    }

    planets.display();
    planets.update();
    
    spaceShip.drawSpaceShip();
    spaceShip.move();
    spaceShip.win(planets.earthX, planets.earthY);
    
    for (let i=0; i<asteroids.length; i++){
      asteroids[i].drawAsteroid();
      asteroids[i].move();
      asteroids[i].update();
      spaceShip.intersects(asteroids[i].position, asteroids[i].size);
      if (collision == true){
        break;
      }
    }
    clownCoordinates[1] = spaceShip.position.y;
    clown.coordinates = clownCoordinates;
    clown.displaySpace();
    if (collision == true){
      //clown.move();
      clownCoordinates[0]+=4;
    }
    if (clownCoordinates[0]>spaceShip.coordinates){
      gameScreen = "gameOverSpace";
    }
  }
  
  if (gameScreen == "gameOverSpace"){
    //resetVariables();
    textAlign(LEFT);
    background(0);
    textSize(70);
    fill(255);
    textFont(titleFont);
    text("Game Over", 150, 100);
    clown.display(150, 300);
    spaceShip.drawSpaceShip();
    
    for (let i = 0; i < 2; i++) {
      fire.push(new Fire());
    }
    for (let i = fire.length - 1; i >= 0; i--) {
      fire[i].update();
      fire[i].drawFire();
      if (fire[i].finished()) {
        fire.splice(i, 1);
        fire.push(new Fire);
      }
    }
    fill(251, 63, 31);
    if(mouseX>370&&mouseX<520&&mouseY>250&&mouseY<325){
      fill(186, 32, 5);
      if (mouseIsPressed){
        gameScreen = "arcade";
      }
    }
    stroke(0);
    rect(370, 250, 150, 75);
    textFont(normalFont);
    textSize(50);
    fill(0);
    text("Home", 395, 300);
  }
  
  if (gameScreen == "winSpace"){
      setCoordinates[2] = 600;
  setCoordinates[3] = 220;
    messages = "Congratulations! You beat all the levels and escaped Krusty the clown! You may now return home.";
    background(0);
    for (let i = 0; i<stars.length; i++){
      stars[i].draw();
    }
    //setCoordinates[0] = 600;
    //setCoordinates[1] = 220;
    spaceShip.position.x = 200;
    spaceShip.position.y = 220;
    spaceShip.drawSpaceShip();
    planets.display();
    guide.coordinates = setCoordinates;
    guide.displaySpace();
    speechBubble[1].coordinates = guide.coordinates;
    speechBubble[1].bubble(messages, 14, -232, -123);
    
    fill(215, 180, 243);
    if(mouseX<870&&mouseX>770&&mouseY>420&&mouseY<470){
      fill(188, 154, 215)
      if (mouseIsPressed){
        next = true;
      }
    }
    stroke(0);
    strokeWeight(3);
    rect(770, 420, 100, 50);
    textSize(25);
    fill(0)
    text("Next", 819, 452);
    
    portal.drawPortal();
    portal.move();
    if (next == true){
      portal.grow();
    }
    if (portal.size>1800){
      gameScreen = "arcade";
    }
  }
  
  //zombies
  if (gameScreen == "zombieInstructions"){
    guide.coordinates = setCoordinates;
    character.coordinates = characterCoordinates;
      background(165, 185, 255)
  if(timer < 10){
    background(30, 65, 180)
     for(let i = 0; i<50; i++){
    fill('white')
       stroke('white')
    circle(random(0, 900), random(0, 500), random(0, 3))
  }
  }
  drawBuildings.display()
      fill(139, 255, 221)
  rect(0, 490, width, 500)
    setCoordinates[0] = 740;
    setCoordinates[1] = 360;
    guide.coordinates = setCoordinates;
    guide.display();
    character.display();
    vector.x = setCoordinates[0];
    vector.y = 410;
    speechBubble[2].coordinates = vector;
    messages = "Use your mouse to click and kill the zombie invaders in your city! You have 20 seconds to kill 25 zombies. Goodluck!"
    speechBubble[2].bubble(messages, 12, -235, -120);
    if(mouseX>=800 && mouseX<=880 && mouseY >=430 && mouseY<=430+45){
      fill(146, 255, 172)
          if(mouseIsPressed){
            gameScreen = 'zombieGame'
          }
    }
    else{
      fill(172, 217, 255)
    }
    strokeWeight(4)
    stroke('blue')
    rect(800, 430, 80, 45 )
    textSize(30)
    textFont(normalFont)
    stroke(0)
    fill(0)
    strokeWeight(2)
    text("Play", 840, 462)
  }
    if (gameScreen == 'zombieGame'){
      character.coordinates = characterCoordinates;
      textAlign(LEFT);
  background(165, 185, 255)
  if(timer < 10){
    background(30, 65, 180)
     for(let i = 0; i<50; i++){
    fill('white')
       stroke('white')
    circle(random(0, 900), random(0, 500), random(0, 3))
  }
  }
  drawBuildings.display()
  //drawBuilding();
  textSize(30);
  strokeWeight(2);
  fill(0)
  stroke(0)
  textFont(normalFont)
  //text('use arrow keys to move', 10, 450)
  //text('click zombie to kill it', 10, 480)
  
  score.display()
  for(let i = 0; i<zombiesRight.length; i++){
 zombiesRight[i].display()
 zombiesRight[i].move()
  }
  
    for(let j = 0; j<zombiesLeft.length; j++){
 zombiesLeft[j].display()
 zombiesLeft[j].move()
  }
  fill(139, 255, 221)
  rect(0, 490, width, 500)
  character.display()
  mouseClicked()
  collisionZombies.check();
    
   if (scoreNum == 25){
    gameScreen = 'winZombies'
  }
  if(timer == 0){
    gameScreen = 'lose'
  }
}
if(gameScreen == 'winZombies'){
  background(250, 210, 255)
  
  //texts
  stroke(80, 40, 255)
  textSize(50)
  fill('red')
  strokeWeight(5)
  textFont(titleFont)
  text("Level Complete!", 80, 300);
  textFont(normalFont)
  textSize(20)
  fill(0)
  strokeWeight(1)
  text('Congrats! You defeated 25 zombies! You may now proceed to outer space\nto complete your last mission.', 105, 130)
  
  //button
  nextButton.display();
  blood.display()
  knife.display()
}
  
if(gameScreen == 'lose'){
  resetVariables();
  textAlign(LEFT);
   background(250, 210, 255)
  clownCoordinates[0] = 450;
  clownCoordinates[1] = 50;
  //texts
  stroke(80, 40, 255)
  textSize(70)
  fill('red')
  strokeWeight(5)
  textFont(titleFont)
  text("Game Over", 130, 300);
  textFont(normalFont)
  textSize(20)
  fill(0)
  strokeWeight(1)
  text('You Lost :(', 370, 400)
  
  //button
  homeButton.display()
  homeButton.colourChange()
  homeButton.next();
  blood.display()
  knife.display()
  clown.display(clownCoordinates[0], clownCoordinates[1])
}
  if(gameScreen == "arcade"){
    textAlign(LEFT);
    timerButton3++;
    character.coordinates = characterCoordinates;
    background('lightblue')
    aBuilding.display()
    aBuilding.floor()
    aBuilding.lights()
    aBuilding.startButton()
    resetVariables();
  }
  
  if(gameScreen == 'chase'){
    timerButton3 = 0;
    messages = "Welcome! You have entered a 50 year old arcade now owned by KRUSTY THE CLOWN! Complete the following challenges to escape Krusty.";
    timerButton1++
    setCoordinates[0] = 50;
    setCoordinates[1] = 370;
    guide.coordinates = setCoordinates;
    //clownCoordinates[0] = 430;
    //clownCoordinates[1] = 0;
    chaseScene.display()
    chaseScene.button();
    chaseScene.textBox();
    guide.display()
    clown.display(clownCoordinates[2], clownCoordinates[3])
    clown.move()
    clownCoordinates[2] = clown.coordinates[0];
    clownCoordinates[3] = clown.coordinates[1];
    speechBubble[3].bubble(messages, 10, setCoordinates[0]+3, 275);
    textAlign(LEFT);
  }
}

function mouseClicked(){
  stroke('red')
  fill('red')
  strokeWeight(3)
  triangle(character.position.x-13, character.position.y+2, character.position.x+13, character.position.y+2, mouseX, mouseY)
  //line(character.x, character.y-45, mouseX, mouseY)
}

function keyPressed() {
    if (keyCode == 37) { //left
      character.moveLeft(); //invoke the moveLeft method of the character
    }  
    else if (keyCode == 39) { //right
      character.moveRight();
    }  
    else if (keyCode == 38) { //up
      character.moveUp();
    }  
    else if (keyCode == 40) { //down
      character.moveDown();
    } 
}
function startingBlock() {
  fill(144, 85, 202);
  rect(startBX, startBY, 100, 30);
}

function resetVariables(){
  forestTimer = 30;
  timerWait = 0;
  forestscore = 0;
  next = false;
  collision = false;
  scoreNum = 0;
  timer = 20;
  timer2 = 100;
  windows = 'yellow';
  for(let i = 0; i<20; i++){
    zombiesRight[i] = new Zombie (random(-500, width), random(30, 200), random(1, 3))
  }
  
  for(let i = 0; i<20; i++){
    zombiesLeft[i] = new Zombie2 (random(width+100, 150), random(30, 200), random(1, 3))
  }
  clownCoordinates[0] = -20;
  clownCoordinates[2] = 450;
  clownCoordinates[3] = 70;
  setCoordinates[2] = 700;
  setCoordinates[3] = 220;
  setCoordinates[4] = 730;
  setCoordinates[5] = 360;
  setCoordinates[6] = 600;
  setCoordinates[7] = 220;
  characterCoordinates[0] = 250;
  characterCoordinates[1] = 200;
  characterCoordinates[2] = 420;
  characterCoordinates[3] = 365;
  spaceShip.position.x = 200;
  spaceShip.position.y = 250;
  timerButton1 = 0;
  timerButton2 = 0;
  planets.redX = 600;
  planets.redY = 400;
  planets.purpleX = 1800;
  planets.purpleY = 160;
  planets.blueX = 3000;
  planets.blueY = 300;
  planets.yellowX = 4200;
  planets.yellowY = 250;
  planets.earthX = 5500;
  planets.earthY = 250;
  portal.position.z = 150;
  startBX = 250;
  
  for (let i = 0; i<asteroids.length; i++){
    asteroids[i].position.x = random(1100, 2000);
  }
}

class MainCharacter{
  constructor(){
    //this.position = new p5.Vector(300, 275);
    this.position = createVector(300, 275);
    this.velocity = createVector(0, 0);
    this.falling = createVector(0, 0);
    //this.isFall = true; 
  }
  display(){
    noStroke();
    fill(223, 163, 8);
    angleMode(DEGREES);
    arc(this.position.x, this.position.y+45, 60, 150, 180, 360);
    fill(238, 205, 158);
    ellipse(this.position.x, this.position.y, 50, 60);
    ellipse(this.position.x+25, this.position.y-4, 10, 20);
    ellipse(this.position.x-25, this.position.y-4, 10, 20);
    fill(223, 163, 8);
    // hair 
    noStroke();
    arc(this.position.x-10, this.position.y-28, 20, 30, 50, 135);
    arc(this.position.x+7, this.position.y-30, 29, 29, 42, 177);
    arc(this.position.x-14, this.position.y-16, 12, 10, 315, 620);
    arc(this.position.x-22, this.position.y-7.5, 10, 15, 270, 450);
    noFill();
    stroke(223, 163, 8);
    strokeWeight(5);
    arc(this.position.x, this.position.y-0, 50, 60, 213, 330);
    stroke(193, 140, 4);
    strokeWeight(2);
    line(this.position.x-9, this.position.y-29, this.position.x-3, this.position.y-19);
    noStroke();
    fill(0);
    ellipse(this.position.x-10, this.position.y-1, 7, 7);
    ellipse(this.position.x+8, this.position.y-1, 7, 7);
    fill(255);
    ellipse(this.position.x-9.5, this.position.y-0.5, 3, 3);
    ellipse(this.position.x+7.5, this.position.y-0.5, 3, 3);
    noFill();
    stroke(0);
    strokeWeight(1);    
    arc(this.position.x-10, this.position.y-5, 7, 7, 220, 300);
    arc(this.position.x+8, this.position.y-5, 7, 7, 220, 300);
    line(this.position.x-2, this.position.y+6, this.position.x-4, this.position.y+12);
    line(this.position.x-4, this.position.y+12, this.position.x-2, this.position.y+12);
    arc(this.position.x-1, this.position.y+19, 10, 7, 5, 160);
    noStroke();
    fill(238, 205, 158);
    rect(this.position.x-6, this.position.y+24, 9, 16);
    stroke(184, 147, 240 );
    strokeWeight(3);
    arc(this.position.x-1.5, this.position.y+35, 9, 6, 0, 180);
    fill(184, 147, 240);
    arc(this.position.x-12, this.position.y+60, 20, 50, 180, 270);
    arc(this.position.x+7, this.position.y+60, 20, 50, 270, 360);
    rect(this.position.x-12, this.position.y+35, 19, 45);
    quad(this.position.x-12, this.position.y+80, this.position.x+7, this.position.y+80, this.position.x+20, this.position.y+95, this.position.x-24, this.position.y+95);
    fill(238, 205, 158);
    noStroke();
    rect(this.position.x-12, this.position.y+96.5, 19, 25);
    //rect(this.position.x-13.5, this.position.y+80, 22, 40)
    stroke(158, 112, 225);
    strokeWeight(4);
    line(this.position.x-12, this.position.y+72, this.position.x+7, this.position.y+72);
    stroke(0);
    strokeWeight(0.5);
    line(this.position.x-2.5, this.position.y+96.5, this.position.x-2.5, this.position.y+120);
    fill(238, 205, 158);
    noStroke();
    rect(this.position.x+8.5, this.position.y+60.1, 9, 20);
    rect(this.position.x-21.5, this.position.y+60.1, 9, 20);
    arc(this.position.x-17, this.position.y+79, 9, 19, 0, 180);
    arc(this.position.x+13, this.position.y+79, 9, 19, 0, 180);
    stroke(0);
    strokeWeight(0.5);
    noFill();
    arc(this.position.x-12, this.position.y+86, 10, 10, 150, 230);
    arc(this.position.x+8, this.position.y+86, 10, 10, 300, 392);
    fill(184, 147, 240);
    noStroke();
    quad(this.position.x-12, this.position.y+115, this.position.x+7, this.position.y+115, this.position.x+13, this.position.y+125, this.position.x-18, this.position.y+125);
    stroke(0);
    strokeWeight(0.5);
    line(this.position.x-2.5, this.position.y+115, this.position.x-2.5, this.position.y+125);
  }
  
  onBlock(other) {
    this.position.y = other.py-125;
    this.position.y = this.position.y;
    this.position.x = this.position.x;
  }
  
    moveLeft() {
      this.position.x-=80;
    }
    moveRight() {
      this.position.x+=80;
    }
    moveUp() {
      this.position.y-=80;
    }
    moveDown() {
      this.position.y+=80;
    }
  
  gravity(){ 
    this.position.y+=3;
    }
  
  //if character in forest game is out of frame
  outOfFrame() {
    if(this.position.x>900) {
      this.position.x=0; 
    }
    else if (this.position.y<0) {
      this.position.y=0;
    }
  }

  intersects(other){
    return (this.position.x < other.px+other.pw) && (this.position.x+this.position.z > other.px) && (this.position.y < other.py+130) && (this.position.y+130 > other.py); 
    }

  gameover(){
    strokeWeight(1)
    if ((this.position.y>=300 && forestTimer>0)||this.position.x>width+20||this.position.y<-50) {
      //resetVariables();
      this.position.y = 500;
      forestTimer = 10;
      background(255, 0, 0);
      //rect(0, 0, 900, 500);
      stroke(0);
      textSize(30); 
      textFont(normalFont); 
      fill(0);
      text("Oh no, you fell into the water!", 210, 150);
      textSize(50);
      textFont(titleFont); 
      fill(255);
      text("GAME OVER", 220, 300);
      //home button
      if(mouseX>=375 && mouseX<=515 && mouseY>=350 && mouseY<=400) {
        fill(200); // click color
        if (mouseIsPressed){
          gameScreen = "arcade";
        }
      }
      rect(375, 350, 140, 50);
      textSize(25);
      fill(0);
      text("Home", 395, 390)
      textFont(normalFont); 
    } 
    else if (forestTimer==0) {
      fill(95, 222, 91);
      rect(0, 0, 900, 500);
      textSize(30); 
      textFont(normalFont); 
      fill(0);
      text("                  Times up!\nCongratulations, you did not fall in the water!", 100, 100);
      textSize(50);
      textFont(titleFont); 
      fill(255);
      text("LEVEL COMPLETED", 80, 300);
      //home button
      if(mouseX>=370 && mouseX<=540 && mouseY>=350 && mouseY<=400) {
        fill(200); // click color
        if (mouseIsPressed){
          gameScreen = "zombieInstructions";
        }
      }
      rect(370, 350, 140, 50);
      textSize(25);
      fill(0);
      text("Next", 390, 390)
    }
  }
  
  set coordinates(coordinates){
    if (gameScreen == "arcade"){
      this.position.x = coordinates[0];
      this.position.y = coordinates[1];
    }
    if (gameScreen == "zombieInstructions"){
      this.position.x = coordinates[2];
      this.position.y = coordinates[3];
    }
  }
  get coordinates(){
    return this.position;
  }
  
  
}


//game 1: forest game ------------------------------------------------------------------------
class ForestStoryLine {
  constructor() {
    this.position = new p5.Vector();
    this.timerText = 0;
  }
  bubble(message, size, x, y) {
    fill(159, 217, 161);
    noStroke();
    ellipse(this.position.x-150, this.position.y-100, 200, 120);
    triangle(this.position.x-43, this.position.y-60, this.position.x-100, this.position.y-70, this.position.x-70, this.position.y-100);
    
    stroke(0);
    fill(0);
  //  textFont(normalFont);
    textSize(size);
   if (this.timerText<message.length){
      this.timerText+=0.3;
      text(message.substring(0, this.timerText), x, y);
    }
    else{
      text(message, x, y);
    }
    
  }
}

class TreeBg {
  constructor(treeX, treeY, treeW, treeH) { 
    this.treeX = treeX;  
    this.treeY = treeY; 
    this.treeW = treeW;   
    this.treeH = treeH;  
  }
  display() {
    noStroke();
    fill(94, 42, 11);
    rect(this.treeX+10, this.treeY, this.treeW, this.treeH);
    fill(66, 133, 91);
    ellipse(this.treeX+20, this.treeY-50, this.treeW+40, this.treeH-40);
    ellipse(this.treeX, this.treeY-20, this.treeW+40, this.treeH-40);
    ellipse(this.treeX+40, this.treeY-20, this.treeW+40, this.treeH-40);
  }
}

class Platform {
  constructor(px, py, pw, ph, c, speed){    
    //this.position = new p5.Vector(random(100, 1000), random(100, 300), random(80, 180));
    this.px = px; 
    this.py = py; 
    this.pw = pw; 
    this.ph = ph; 
    this.c = c;
    this.speed = speed; 
  }
  display(){
    stroke(0);
    fill(this.c);
    //rect(this.position.x, this.position.y, this.position.z, 30);
    rect(this.px, this.py, this.pw, this.ph); 
  }
  move(){
    this.px-=2;
    if (this.px+this.pw<0){
      this.px = 900
      this.px-= this.speed;
    }
  }
  toString() {
    return ("platform" +this.px +"  " +this.py);
  }
}

//game3: space game --------------------------------------------------------------------------
class Asteroids {
  constructor(){
    this.position = new p5.Vector(random(1100, 2000), random(50, 450), random(1, 4));
    this.size = random(20, 120);
  }
  drawAsteroid(){
    fill(153);
    circle(this.position.x, this.position.y, this.size);
    noStroke();
    fill(128);
    circle(this.position.x-(this.size/3), this.position.y-(this.size/14), this.size/8);
    circle(this.position.x+(this.size/10), this.position.y+(this.size/6), this.size/4);
    circle(this.position.x+(this.size/7), this.position.y-(this.size/5), this.size/7)
    fill(204, 204, 179);
    circle(this.position.x-(this.size/4), this.position.y-(this.size/10), this.size/10);
    circle(this.position.x+(this.size/5), this.position.y+(this.size/5), this.size/5);
    circle(this.position.x+(this.size/6), this.position.y-(this.size/4), this.size/8)
  }
  move(){
    this.position.x-=this.position.z;
  }
  update(){
    if(this.position.x<-1*(this.size/2)){
      this.position.x = random(1100, 2000);
      this.position.y = random(50, 450);
      this.position.z = random(1, 4);
      this.size = random(20, 120);
    }
  }
}

class SpaceShip {
  constructor(){
    this.position = new p5.Vector(200, 250);
  }
  drawSpaceShip(){
    if (gameScreen == "gameOverSpace"){
      this.position.x = 750;
      this.position.y = 400;
      strokeWeight(1);
      stroke(0);
      fill(179);
      arc(this.position.x-30, this.position.y+31, 22, 18, 0, 180);
      arc(this.position.x, this.position.y+34, 22, 18, 0, 180);
      arc(this.position.x+30, this.position.y+31, 22, 18, 0, 180);
      fill(255);
      angleMode(DEGREES);
      arc(this.position.x, this.position.y+24, 100, 25, 0, 180);
      fill(204, 102, 255)
      ellipse(this.position.x, this.position.y, 150, 60);
      fill(179);
      ellipse(this.position.x, this.position.y-7, 150, 60);
      fill(153, 51, 255);
      ellipse(this.position.x, this.position.y-15, 100, 30);
      fill(255);
      noStroke();
      rect(this.position.x-20, this.position.y-29, 40, 20);
      arc(this.position.x, this.position.y-1, 50, 30, 182, 358);
      strokeWeight(1);
      stroke(0);
      circle(this.position.x, this.position.y-45, 50);
      arc(this.position.x-23, this.position.y-45, 15, 20, 90, 270);
      arc(this.position.x+23, this.position.y-45, 15, 20, 270, 450);
      arc(this.position.x+15, this.position.y-10, 25, 40, 280, 396);
      arc(this.position.x-15, this.position.y-10, 25, 40, 143, 257);
      arc(this.position.x+15, this.position.y-8, 20, 13, 90, 270);
      arc(this.position.x-15, this.position.y-8, 20, 13, 270, 450);
      fill(26, 19, 0);
      arc(this.position.x, this.position.y-39, 35, 45, 180, 360);
      arc(this.position.x, this.position.y-39, 35, 25, 0, 180);
      fill(153, 204, 255, 100);
      arc(this.position.x, this.position.y-15, 100, 130, 180, 360)
      arc(this.position.x, this.position.y-15, 100, 30, 0, 180);
    }
    else{
      strokeWeight(1);
      stroke(0);
      fill(179);
      arc(this.position.x-30, this.position.y+31, 22, 18, 0, 180);
      arc(this.position.x, this.position.y+34, 22, 18, 0, 180);
      arc(this.position.x+30, this.position.y+31, 22, 18, 0, 180);
      fill(255);
      angleMode(DEGREES);
      arc(this.position.x, this.position.y+24, 100, 25, 0, 180);
      fill(204, 102, 255)
      ellipse(this.position.x, this.position.y, 150, 60);
      fill(179);
      ellipse(this.position.x, this.position.y-7, 150, 60);
      fill(153, 51, 255);
      ellipse(this.position.x, this.position.y-15, 100, 30);
      //character 
      noStroke();
      fill(223, 163, 8);
      angleMode(DEGREES);
      arc(this.position.x+0.5, this.position.y-20, 60, 150, 180, 360);
      fill(238, 205, 158);
      ellipse(this.position.x, this.position.y-65, 50, 60);
      ellipse(this.position.x+25, this.position.y-69, 10, 20);
      ellipse(this.position.x-25, this.position.y-69, 10, 20);
      fill(223, 163, 8);
      // hair 
      arc(this.position.x-10, this.position.y-93, 20, 30, 50, 135);
      arc(this.position.x+7, this.position.y-95, 29, 29, 42, 177);
      arc(this.position.x-14, this.position.y-81, 12, 10, 315, 620);
      arc(this.position.x-22, this.position.y-72.5, 10, 15, 270, 450);
      noFill();
      stroke(223, 163, 8);
      strokeWeight(5);
      arc(this.position.x, this.position.y-65, 50, 60, 213, 330);
      stroke(193, 140, 4);
      strokeWeight(2);
      line(this.position.x-9, this.position.y-94, this.position.x-3, this.position.y-84);
      noStroke();
      fill(0);
      ellipse(this.position.x-10, this.position.y-66, 7, 7);
      ellipse(this.position.x+8, this.position.y-66, 7, 7);
      fill(255);
      ellipse(this.position.x-9.5, this.position.y-65.5, 3, 3);
      ellipse(this.position.x+7.5, this.position.y-65.5, 3, 3);
      noFill();
      stroke(0);
      strokeWeight(1);    
      arc(this.position.x-10, this.position.y-70, 7, 7, 220, 300);
      arc(this.position.x+8, this.position.y-70, 7, 7, 220, 300);
      line(this.position.x-2, this.position.y-59, this.position.x-4, this.position.y-53);
      line(this.position.x-4, this.position.y-53, this.position.x-2, this.position.y-53);
      arc(this.position.x-1, this.position.y-46, 10, 7, 5, 160);
      noStroke();
      fill(238, 205, 158);
      rect(this.position.x-6, this.position.y-41, 9, 16);
      stroke(184, 147, 240 );
      strokeWeight(3);
      arc(this.position.x-1.5, this.position.y-30, 9, 6, 0, 180);
      fill(184, 147, 240);
      arc(this.position.x-12, this.position.y-5, 20, 50, 180, 270);
      arc(this.position.x+7, this.position.y-5, 20, 50, 270, 360);
      rect(this.position.x-12, this.position.y-30, 19, 28);
      fill(238, 205, 158);
      noStroke();
      rect(this.position.x+8.5, this.position.y-4.9, 9, 5);
      rect(this.position.x-21.5, this.position.y-4.9, 9, 4);
      stroke(0);
      strokeWeight(1);
      fill(153, 204, 255, 100);
      arc(this.position.x, this.position.y-15, 100, 180, 180, 360)
      arc(this.position.x, this.position.y-15, 100, 30, 0, 180);
    }
  } 
  move(){
    if (keyIsDown(UP_ARROW)){
      this.position.y-=4;
    }
    if (keyIsDown(DOWN_ARROW)){
      this.position.y+=4;
    }
    if (keyIsDown(LEFT_ARROW)){
      this.position.x-=4;
    }
    if (keyIsDown(RIGHT_ARROW)){
      this.position.x+=4;
    }
  }
  intersects(asteroidPosition, size){
    if (this.position.x+75<0||this.position.x-75>width||this.position.y+30<0||this.position.y-70>height){
      gameScreen = "gameOverSpace";
    }
    if (this.position.x+37>asteroidPosition.x-(size/2)&&this.position.x-37<asteroidPosition.x+(size/2)&&this.position.y+17>asteroidPosition.y-(size/2)&&this.position.y-27<asteroidPosition.y+(size/2)){
      collision = true;
    }
  }
  win(earthX, earthY){
    if (this.position.x+40>earthX-250&&this.position.y+20>earthY-250&&this.position.y-30<earthY+250){
      gameScreen = "winSpace";
    }
  }
  get coordinates(){
    return this.position.x;
  }
}

//make timer and at the end of the timer generate new position and time values
class Stars {
  constructor(){
   this.position = new p5.Vector(random(0, width), random(0, height), random(0.25, 2.5));
    this.time = random(0,TWO_PI);
  }
  draw(){
    fill(255);
    angleMode(RADIANS);
    this.time += 0.1;
    let scale = this.position.z + sin (this.time) * 2;
	noStroke();
	ellipse(this.position.x, this.position.y, scale, scale);
  }
}

class Planets{
  constructor(){
    this.redX = 600;
    this.redY = 400;
    this.purpleX = 1800;
    this.purpleY = 160;
    this.blueX = 3000;
    this.blueY = 300;
    this.yellowX = 4200;
    this.yellowY = 250;
    this.earthX = 5500;
    this.earthY = 250;
  }
  display(){
    angleMode(DEGREES);
    //red planet
    fill(222, 109, 64, 245);
    circle(this.redX, this.redY, 400);  
    strokeWeight(3);
    stroke(247, 142, 68);
    line(this.redX, this.redY+20, this.redX+91, this.redY+20);
    line(this.redX-50, this.redY-80, this.redX+50, this.redY-80);
    line(this.redX-63, this.redY-20, this.redX+15, this.redY-20);
    fill(247, 142, 68);
    ellipse(this.redX, this.redY+78, 50, 20);
    
    //purple planet
    stroke(242, 175, 255);
    fill(242, 175, 255);
    circle(this.purpleX, this.purpleY, 280);
    strokeWeight(1.5);
    fill(152, 27, 165);
    stroke(152, 27, 165);
    ellipse(this.purpleX-80, this.purpleY, 20, 15);
    ellipse(this.purpleX-10, this.purpleY+100, 15, 10);
    ellipse(this.purpleX+30, this.purpleY-60, 10, 10);
    ellipse(this.purpleX+10, this.purpleY-10, 20, 14);
    ellipse(this.purpleX+80, this.purpleY+80, 15, 10);
    ellipse(this.purpleX+15, this.purpleY+40, 8, 6);
    ellipse(this.purpleX-50, this.purpleY-50, 10, 10)
    
    //blue planet
    noStroke();
    fill(145, 201, 219);
    circle(this.blueX, this.blueY, 350);
    fill(67, 132, 217);
    arc(this.blueX-85, this.blueY-100, 90, 90, 200, 230);
    arc(this.blueX+85, this.blueY-100, 90, 90, 310, 340);
    rect(this.blueX-115, this.blueY-135, 230, 35);
    arc(this.blueX-97, this.blueY-100, 80, 60, 180, 220);
    arc(this.blueX+97, this.blueY-100, 80, 60, 320, 360);
    arc(this.blueX-130, this.blueY-20, 90, 100, 180, 220);
    arc(this.blueX-130, this.blueY-20, 92, 100, 150, 180);
    rect(this.blueX-170, this.blueY-48, 340, 50);
    arc(this.blueX+130, this.blueY-20, 90, 80, 320, 360);
    arc(this.blueX+130, this.blueY-20, 90, 80, 0, 30);
    //arc(this.blueX-100, this.blueY+98, 80, 60, 160, 270);
    triangle(this.blueX-135, this.blueY+70, this.blueX-160, this.blueY+70, this.blueX-135, this.blueY+115);
    triangle(this.blueX+135, this.blueY+70, this.blueX+160, this.blueY+70, this.blueX+135, this.blueY+115)
    rect(this.blueX-135, this.blueY+70, 270, 45);
    
    //smiley face planet
    fill(252, 237, 87);
    circle(this.yellowX, this.yellowY, 250);
    fill(240, 222, 45);
    circle(this.yellowX-50, this.yellowY-40, 20);
    circle(this.yellowX+50, this.yellowY-40, 20);
    noFill();
    stroke(240, 222, 45);
    strokeWeight(3);
    arc(this.yellowX, this.yellowY+20, 50, 30, 0, 180)
    
    //earth
    noStroke();
    fill(42, 140, 241);
    circle(this.earthX, this.earthY, 500);
    fill(66, 166, 7)
    ellipse(this.earthX-130, this.earthY-120, 150, 100);
   // ellipse(this.earthX-80, this.earthY-80, 75, 75);
    ellipse(this.earthX-80, this.earthY-130, 150, 75);
    ellipse(this.earthX+100, this.earthY+100, 200, 150);
    ellipse(this.earthX+120, this.earthY+40, 100, 75);
    ellipse(this.earthX-100, this.earthY+120, 150, 75);
    ellipse(this.earthX-100, this.earthY+100, 100, 100);
    ellipse(this.earthX-60, this.earthY+160, 130, 70);
  //  ellipse(this.earthX-140, this.earthY+160, 70);
    ellipse(this.earthX-180, this.earthY, 100, 70);
    //ellipse(this.earthX-190, this.earthY+20, 50, 50)
    ellipse(this.earthX+150, this.earthY-100, 100, 100);
   // ellipse(this.earthX+125, this.earthY-110, 130, 120);
    ellipse(this.earthX+70, this.earthY-70, 100, 70);
    ellipse(this.earthX-140, this.earthY+40, 60, 100)
    ellipse(this.earthX+70, this.earthY-120, 120);
   // ellipse(this.earthX+40, this.earthY-170, 100, 70);
    ellipse(this.earthX+125, this.earthY-175, 70);
    ellipse(this.earthX+190, this.earthY-120, 40,60)
    ellipse(this.earthX, this.earthY, 70);
    ellipse(this.earthX-20, this.earthY+10, 100, 70)
    
  }
  update(){
    this.redX-=3;
    this.purpleX-=3;
    this.blueX-=3;
    this.yellowX-=3;
    if (this.earthX>850){
      this.earthX-=3;
    }
  }
  
}

class Fire {
  constructor(){
    this.position = new p5.Vector(random(710, 790), 400, 16);
    this.speed = new p5.Vector(random(-1, 1), random(-5,-1));
    this.transparency = 255;
  }
  update(){
    this.position.x+=this.speed.x;
    this.position.y+=this.speed.y;
    this.position.z-= random(0.05, 0.1);
    this.transparency-=3;
  }
  drawFire(){
    noStroke();
    fill(random(200,230), random(50, 150), 10, this.transparency);
    ellipse(this.position.x, this.position.y, this.position.z);
  }
  finished() {
    return this.transparency < 0;
  }
}

class tourGuide{
  constructor(){
    this.position = new p5.Vector(200, 300);
  }
  display(){
    //guide
    fill(227, 180, 113);
    ellipse(this.position.x, this.position.y, 50, 60);
    ellipse(this.position.x+25, this.position.y-4, 10, 20);
    ellipse(this.position.x-25, this.position.y-4, 10, 20);
    fill(140, 107, 60);
    angleMode(DEGREES);
    arc(this.position.x, this.position.y-15, 40, 30, 180, 360);
    triangle(this.position.x-15, this.position.y-15, this.position.x-20, this.position.y-18, this.position.x-25, this.position.y);
    triangle(this.position.x+16, this.position.y-25, this.position.x-10, this.position.y-10, this.position.x-5, this.position.y-20);
    arc(this.position.x+22, this.position.y-8, 10, 15, 90, 270);
    triangle(this.position.x+22, this.position.y-15, this.position.x+4, this.position.y-10, this.position.x+10, this.position.y-25);
    fill(0);
    ellipse(this.position.x-10, this.position.y-1, 7, 7);
    ellipse(this.position.x+8, this.position.y-1, 7, 7);
    fill(255);
    ellipse(this.position.x-9.5, this.position.y-0.5, 3, 3);
    ellipse(this.position.x+7.5, this.position.y-0.5, 3, 3);
    noFill();
    stroke(0);
    strokeWeight(1);    
    arc(this.position.x-10, this.position.y-5, 7, 7, 220, 300);
    arc(this.position.x+8, this.position.y-5, 7, 7, 220, 300);
    line(this.position.x-2, this.position.y+6, this.position.x-4, this.position.y+12);
    line(this.position.x-4, this.position.y+12, this.position.x-2, this.position.y+12);
    arc(this.position.x-1, this.position.y+19, 10, 7, 5, 160);
    fill(227, 180, 113);
    noStroke();
    rect(this.position.x-6, this.position.y+24, 9, 16);
    stroke(40, 165, 15);
    strokeWeight(3);
    arc(this.position.x-1.5, this.position.y+35, 9, 6, 0, 180);
    fill(40, 165, 15);
    arc(this.position.x-12, this.position.y+60, 20, 50, 180, 270);
    arc(this.position.x+7, this.position.y+60, 20, 50, 270, 360);
    rect(this.position.x-12, this.position.y+35, 19, 45);
    fill(107, 166, 226);
    noStroke();
    rect(this.position.x-13.5, this.position.y+80, 22, 40)
    stroke(0);
    strokeWeight(0.5);
    line(this.position.x-2.5, this.position.y+81, this.position.x-2.5, this.position.y+120);
    fill(227, 180, 113);
    noStroke();
    rect(this.position.x+8.5, this.position.y+60.1, 9, 20);
    rect(this.position.x-21.5, this.position.y+60.1, 9, 20);
    arc(this.position.x-17, this.position.y+79, 9, 19, 0, 180);
    arc(this.position.x+13, this.position.y+79, 9, 19, 0, 180);
    stroke(0);
    noFill();
    arc(this.position.x-12, this.position.y+86, 10, 10, 150, 230);
    arc(this.position.x+8, this.position.y+86, 10, 10, 300, 400);
    fill(79, 51, 3);
    noStroke();
    quad(this.position.x-13.5, this.position.y+120, this.position.x+8.5, this.position.y+120, this.position.x+13, this.position.y+130, this.position.x-18, this.position.y+130);
    stroke(0);
    strokeWeight(0.5);
    line(this.position.x-2.5, this.position.y+120, this.position.x-2.5, this.position.y+130);
  } 
  displaySpace(){
    //this.position.x = 700;
    //this.position.y = 220;
    strokeWeight(1);
    stroke(0);
    fill(179);
    arc(this.position.x-30, this.position.y+31, 22, 18, 0, 180);
    arc(this.position.x, this.position.y+34, 22, 18, 0, 180);
    arc(this.position.x+30, this.position.y+31, 22, 18, 0, 180);
    fill(255);
    angleMode(DEGREES);
    arc(this.position.x, this.position.y+24, 100, 25, 0, 180);
    fill(24, 204, 76)
    ellipse(this.position.x, this.position.y, 150, 60);
    fill(179);
    ellipse(this.position.x, this.position.y-7, 150, 60);         
    fill(20, 191, 69);
    ellipse(this.position.x, this.position.y-15, 100, 30);
    //guide
    noStroke();
    fill(227, 180, 113);
    ellipse(this.position.x, this.position.y-67, 50, 60);
    ellipse(this.position.x+25, this.position.y-71, 10, 20);
    ellipse(this.position.x-25, this.position.y-71, 10, 20);
    fill(140, 107, 60);
    angleMode(DEGREES);
    arc(this.position.x, this.position.y-82, 40, 30, 180, 360);
    triangle(this.position.x-15, this.position.y-82, this.position.x-20, this.position.y-85, this.position.x-25, this.position.y-67);
    triangle(this.position.x+16, this.position.y-92, this.position.x-10, this.position.y-77, this.position.x-5, this.position.y-87);
    arc(this.position.x+22, this.position.y-75, 10, 15, 90, 270);
    triangle(this.position.x+22, this.position.y-82, this.position.x+4, this.position.y-77, this.position.x+10, this.position.y-92)
    fill(0);
    ellipse(this.position.x-10, this.position.y-68, 7, 7);
    ellipse(this.position.x+8, this.position.y-68, 7, 7);
    fill(255);
    ellipse(this.position.x-9.5, this.position.y-67.5, 3, 3);
    ellipse(this.position.x+7.5, this.position.y-67.5, 3, 3);
    noFill();
    stroke(0);
    strokeWeight(1);    
    arc(this.position.x-10, this.position.y-72, 7, 7, 220, 300);
    arc(this.position.x+8, this.position.y-72, 7, 7, 220, 300);
    line(this.position.x-2, this.position.y-61, this.position.x-4, this.position.y-55);
    line(this.position.x-4, this.position.y-55, this.position.x-2, this.position.y-55);
    arc(this.position.x-1, this.position.y-48, 10, 7, 5, 160);
    fill(227, 180, 113);
    noStroke();
    rect(this.position.x-6, this.position.y-43, 9, 16);
    stroke(40, 165, 15);
    strokeWeight(3);
    arc(this.position.x-1.5, this.position.y-33, 9, 6, 0, 180);
    fill(40, 165, 15);
    arc(this.position.x-12, this.position.y-7, 20, 50, 180, 270);
    arc(this.position.x+7, this.position.y-7, 20, 50, 270, 360);
    rect(this.position.x-12, this.position.y-32, 19, 30);
    fill(227, 180, 113);
    noStroke();
    rect(this.position.x+8.5, this.position.y-7.1, 9, 7);
    rect(this.position.x-21.5, this.position.y-7.1, 9, 7);
    stroke(0);
    strokeWeight(1);
    fill(153, 204, 255, 100);
    arc(this.position.x, this.position.y-15, 100, 180, 180, 360)
    arc(this.position.x, this.position.y-15, 100, 30, 0, 180);
  }
  set coordinates(xAndy){
    if (gameScreen == "chase"){
      this.position.x = xAndy[0];
    this.position.y = xAndy[1];
    }
    if (gameScreen == "instructionsSpace"){
      this.position.x = xAndy[2];
      this.position.y = xAndy[3];
    }
    if (gameScreen == "zombieInstructions"){
      this.position.x = xAndy[4];
      this.position.y = xAndy[5];
    }
    if (gameScreen == "winSpace"){
      this.position.x = xAndy[6];
      this.position.y = xAndy[7];
    }
  }
  get coordinates(){
    return this.position;
  }
}

class SpeechBubble{
  constructor(){
    this.position = new p5.Vector();
    this.timer = 0;
  }
  bubble(message, size, x, y){
    fill(255);
    noStroke();
    ellipse(this.position.x-150, this.position.y-100, 200, 120);
    triangle(this.position.x-43, this.position.y-60, this.position.x-100, this.position.y-70, this.position.x-70, this.position.y-100);
    fill(0);
    textAlign(CENTER);
    textFont(normalFont);
    textSize(size);
    if (this.timer<message.length){
      this.timer+=0.3;
      text(message.substring(0, this.timer), this.position.x+x, this.position.y+y, 170, 100);
    }
    else{
      text(message, this.position.x+x, this.position.y+y, 170, 100);
    }
  }
  set coordinates(xAndy){
    this.position.x = xAndy.x;
    this.position.y = xAndy.y;
  }
  get coordinates(){
    
  }
}

class Clown{
  constructor(x, y){
    this.x = x;
    this.y = y
    this.knife = new Knife(this.x+20, this.y);
  }
  display(x, y){
    this.x = x;
    this.y = y;
    this.knife.x = this.x+55;
    this.knife.y = this.y+20;
  //Head
    angleMode(RADIANS);
  noStroke();
  fill (255, 240, 205);
  circle (this.x, this.y, 50);
  fill (155, 50, 20);
  quad (this.x - 21, this.y - 15, this.x - 32.5, this.y - 15, this.x - 21, this.y + 15, this.x - 17.5, this.y);
  fill (255, 0, 0);
  circle (this.x + 7.5, this.y + 2.5, 10);
  fill (0);
  circle (this.x - 5, this.y - 5, 5);
  circle (this.x + 15, this.y - 5, 5);
  strokeWeight (3);
  stroke(0);
  noFill();
  line (this.x - 10, this.y - 10, this.x, this.y - 5);
  line (this.x + 20, this.y - 10, this.x + 10, this.y - 5);
  arc (this.x + 7.5, this.y + 16, 15, 10, PI, 0);
  //Body
  noStroke();
  fill (235);
  rect (this.x - 25, this.y + 25, 50, 50);
  fill (255, 0, 0);
  ellipse (this.x, this.y + 35, 10);
  ellipse (this.x, this.y + 50, 10);
  ellipse (this.x, this.y + 65, 10);
  //Arms & Legs
  fill (120);
  quad (this.x - 25, this.y + 25, this.x - 25, this.y + 40, this.x + 20, this.y + 47.5, this.x + 20, this.y + 32.5);
  quad (this.x + 25, this.y + 25, this.x + 25, this.y + 40, this.x + 60, this.y + 45, this.x + 60, this.y + 30);
  fill (255, 240, 205);
  circle (this.x + 20, this.y + 40, 15);
  circle (this.x + 60, this.y + 37.5, 15);
  fill (150);
  quad (this.x - 25, this.y + 75, this.x - 2.5, this.y + 75, this.x - 7.5, this.y + 125, this.x - 25, this.y + 125);
  quad (this.x + 2.5, this.y + 75, this.x + 25, this.y + 75, this.x + 25, this.y + 125, this.x + 7.5, this.y + 125);
  fill (80);
  rect (this.x - 25, this.y + 115, 25, 10);
  rect (this.x + 5, this.y + 115, 25, 10);
    this.knife.display();
  }
  set coordinates(xAndy){
    this.x = xAndy[0];
    this.y = xAndy[1];
    this.knife.x = xAndy[0]+20;
    this.knife.y = xAndy[1];
  }
  get coordinates(){
    let toReturn = [];
    toReturn[0] = this.x;
    toReturn[1] = this.y;
    //return this.x;
    return toReturn;
  }
  displaySpace(){
    strokeWeight(1);
    stroke(0);
    fill(179);
    arc(this.x-30, this.y+31, 22, 18, 0, 180);
    arc(this.x, this.y+34, 22, 18, 0, 180);
    arc(this.x+30, this.y+31, 22, 18, 0, 180);
    fill(255);
    angleMode(DEGREES);
    arc(this.x, this.y+24, 100, 25, 0, 180);
    fill(236, 51, 23)
    ellipse(this.x, this.y, 150, 60);
    fill(179);
    ellipse(this.x, this.y-7, 150, 60);         
    fill(223, 39, 11);
    ellipse(this.x, this.y-15, 100, 30);
    angleMode(RADIANS);
  noStroke();
  fill (255, 240, 205);
  circle (this.x, this.y-60, 50);
  fill (155, 50, 20);
  quad (this.x - 21, this.y - 75, this.x - 32.5, this.y - 75, this.x - 21, this.y-45, this.x - 17.5, this.y-60);
  fill (255, 0, 0);
  circle (this.x + 7.5, this.y-57.5, 10);
  fill (0);
  circle (this.x - 5, this.y-65, 5);
  circle (this.x + 15, this.y -65, 5);
  strokeWeight (3);
  stroke(0);
  noFill();
  line (this.x - 10, this.y - 70, this.x, this.y - 65);
  line (this.x + 20, this.y - 70, this.x + 10, this.y - 65);
  arc (this.x + 7.5, this.y-44, 15, 10, PI, 0);
      //Body
  noStroke();
  fill (235);
  rect (this.x - 25, this.y-35, 50, 34);
  fill (255, 0, 0);
  ellipse (this.x, this.y-25, 10);
  ellipse (this.x, this.y-10, 10);
    fill (120);
  quad (this.x - 25, this.y-35, this.x - 25, this.y-20, this.x + 20, this.y-12.5, this.x + 20, this.y-27.5);
  quad (this.x + 25, this.y-35, this.x + 25, this.y-20, this.x + 40, this.y-15, this.x + 40, this.y-30);
  fill (255, 240, 205);
  circle (this.x + 20, this.y-20, 15);
  circle (this.x + 40, this.y-23.5, 15);
        this.knife.y = this.y-35;
    this.knife.x = this.x+13;
    this.knife.display();
    angleMode(DEGREES);
    stroke(0);
    strokeWeight(1);
    fill(153, 204, 255, 100);
    arc(this.x, this.y-15, 100, 180, 180, 360)
    arc(this.x, this.y-15, 100, 30, 0, 180);
  }
    move(){
    this.y+=1;
  }
}

class Knife{
  constructor(x, y){
    this.x = x;
    this.y = y
  }
  display(){
    noStroke();
    // RIGHT Knife Handle
    fill(80);
    rect(this.x, this.y-5, 10, 30);
    // RIGHT Knife Blade
    fill(160);
    rect(this.x, this.y-40, 25, 40, 5);
    // RIGHT Knife Sharp
    fill(200);
    rect(this.x+15, this.y-40, 10, 40);
    // RIGHT Handle Holes
    circle(this.x+5, this.y+17, 5);
    circle(this.x+5, this.y+7, 5); 
  }
}

class Portal{
  constructor(){
    this.position = new p5.Vector(800, 250, 150);
    this.startAngle = 0;
    this.gradient;
    this.colour1 = color(126, 25, 214);
    this.colour2 = color(32, 40, 247 );
    this.colour3 = color(71, 194, 247 );
    this.colour4 = color(247, 136, 32);
  }
  drawPortal(){
    this.gradient = drawingContext.createConicGradient(this.startAngle, this.position.x, this.position.y);
    //noFill();
    stroke(100, 54, 69);
    this.gradient.addColorStop(0, this.colour1);
    //this.gradient.addColorStop(0.25, this.colour2);
    this.gradient.addColorStop(0.5, this.colour3);
    //this.gradient.addColorStop(0.75, this.colour4);
    this.gradient.addColorStop(1, this.colour1);
    drawingContext.fillStyle = this.gradient;
    ellipse(this.position.x, this.position.y, this.position.z, this.position.z*1.5);
  }
  move(){
    this.startAngle+=0.05;
  }
  grow(){
    this.position.z+=4;
  }
  get size(){
    return this.position.z;
  }
}

//game 2: zombie game -----------------------------------------------------------------------
class Score{
  constructor(x, y){
    this.x = x;
    this.y = y;
  }
  display(){
    strokeWeight(1);
    fill(0);
    textSize(40);
    stroke(0);
    textFont(titleFont);
    text('Score: '+scoreNum, this.x-90, this.y-50);
    
    //timer
    text(timer, 650, 50)
    if (frameCount % 60 == 0 && timer > 0) { // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
    timer --;
  }
  if (timer == 0) {
    stroke('yellow')
    text("GAME OVER", 300, 300);
    //removes all zombies at the end of the game
    for(let i = 0; i<zombiesRight.length; i++){
      zombiesRight.splice(i)
    }
  }
  
  }
}

class DrawBuildings{
  constructor(x, y){
    this.x = x;
    this.y = y;
  }
  display(){
    //buildings
  noStroke()
  fill(132, 171, 181)
  rect(this.x-100, this.y+100, 60, 350)
  
  fill(94, 124, 131)
  rect(this.x-40, this.y+50, 80, 350)
  triangle(this.x-40, this.y+40, this.x+0, this.y+0, this.x+40, this.y+40)
  fill('yellow')
  rect(this.x-40, this.y+40, 80, 20)
  
  fill(177, 180, 181)
  rect(this.x+40,this.y+190,200,290 )  
  ellipse(this.x+140, this.y+190, 200, 100)
  
  fill(60, 97, 100)
  rect(this.x+230, this.y-20, 200, 410)  
  
  fill(windows)
  if(timer <10){
    fill('black')
  }
  
  for(let a = 0; a<350; a+=50){
  for(let i = 0; i<=100; i+=50){
  square(this.x+260+i, this.y+a, 40)
  }
  }
  fill(215, 220, 230)
  rect(this.x+430, this.y+250, 220, 200)
  
  fill(100, 105, 130)
  rect(this.x+650, this.y, 200, 700)
  }
}

//home button
class HomeButton{
  constructor(x, y){
      this.x = x;
      this.y = y;
  }
    colourChange(){
  if(mouseX>=730 && mouseX<=880 && mouseY>=425 && mouseY<=480){
    fill(255,255, 180)
    rect(this.x+630, this.y+325, 150, 55)
  
  textSize(40)
  stroke('blue')
  text('Home...', this.x+640, this.y+365)
  }  
  }
  next(){
    if(mouseX>=730 && mouseX<=880 && mouseY>=425 && mouseY<=480&&mouseIsPressed){
      gameScreen = "arcade";
    }
  }
  display(){
      strokeWeight(3)
      stroke(7, 150, 212)
      fill(40, 255, 205)
    
      rect(this.x+630, this.y+325, 150, 55)
  
  textSize(40)
  fill(7, 150, 212)
  stroke('blue')
  text('Home...', this.x+640, this.y+365)
    }
  }

class Blood{
  constructor(x, y){
    this.x = x;
    this.y = y;
  }
  display(){
    for (var i = 120; i > 0; i-=3) {
      noStroke();
      fill(150 + i, 0, 0, 20);
      ellipse(this.x-30,this.y-30, i, i);
  }
  
    for (var i = 70; i > 0; i-=3) {
      noStroke();
      fill(150 + i, 0, 0, 20);
      ellipse(this.x-60, this.y+70, i, i);
  }
  
  for (var i = 200; i > 0; i-=3) {
      noStroke();
      fill(150 + i, 0, 0, 20);
      ellipse(this.x+150, this.y+410, i, i);
  }
 
  for (var i = 200; i > 0; i-=3) {
      noStroke();
      fill(150 + i, 0, 0, 20);
      ellipse(this.x+790, this.y, i, i);
  }
  }
}

class Zombie2{
  constructor(zombieX, zombieY, zSpeed){
    this.zombieX = zombieX
    this.zombieY = zombieY
    this.zSpeed = zSpeed
  }
  display(){
    //Skull + Hair
  noStroke();
  fill (100, 125, 90);
  rect (this.zombieX, this.zombieY, 60, 55);
  rect (this.zombieX+10, this.zombieY+20, 40, 45);
  fill (40, 20, 5);
  rect (this.zombieX, this.zombieY, 60, 10);
  
  //Eyes + Nose
  fill (0);
  square (this.zombieX+15, this.zombieY+20, 10);
  square (this.zombieX+40, this.zombieY+20, 10);
  stroke (0);
  strokeWeight (3);
  point (this.zombieX+28, this.zombieY+40);
  point (this.zombieX+37,this.zombieY+40);
  
  //Mouth
  strokeWeight (0.5);
  fill (230, 200, 50);
  rect (this.zombieX+15, this.zombieY+54, 30,10);
  line (this.zombieX+15, this.zombieY +60, this.zombieX+44, this.zombieY+60);
  line (this.zombieX+24, this.zombieY+55, this.zombieX+24, this.zombieY+63);
  line (this.zombieX+35, this.zombieY+55, this.zombieX+35, this.zombieY+63);
  line (this.zombieX+23, this.zombieY+55, this.zombieX+23, this.zombieY+63);
    
  }
  move(){
    this.zombieX-= this.zSpeed;
    if(this.zombieX<-50){
      this.zombieX = random(1050, 1200); 
      this.zombieY = random(30, 200)
    }
  }
}

class Zombie{
  constructor(zombieX, zombieY, zSpeed){
    this.zombieX = zombieX
    this.zombieY = zombieY
    this.zSpeed = zSpeed
  }
  display(){
    //Skull + Hair
  noStroke();
  fill (100, 125, 90);
  rect (this.zombieX, this.zombieY, 60, 55);
  rect (this.zombieX+10, this.zombieY+20, 40, 45);
  fill (40, 20, 5);
  rect (this.zombieX, this.zombieY, 60, 10);
  
  //Eyes + Nose
  fill (0);
  square (this.zombieX+15, this.zombieY+20, 10);
  square (this.zombieX+40, this.zombieY+20, 10);
  stroke (0);
  strokeWeight (3);
  point (this.zombieX+28, this.zombieY+40);
  point (this.zombieX+37,this.zombieY+40);
  
  //Mouth
  strokeWeight (0.5);
  fill (230, 200, 50);
  rect (this.zombieX+15, this.zombieY+54, 30,10);
  line (this.zombieX+15, this.zombieY +60, this.zombieX+44, this.zombieY+60);
  line (this.zombieX+24, this.zombieY+55, this.zombieX+24, this.zombieY+63);
  line (this.zombieX+35, this.zombieY+55, this.zombieX+35, this.zombieY+63);
  line (this.zombieX+23, this.zombieY+55, this.zombieX+23, this.zombieY+63);
    
  }
  move(){
    this.zombieX+= this.zSpeed;
    if(this.zombieX>width+100){
      this.zombieX = random(-200, 0); 
      this.zombieY = random(30, 200)
    }
  }
}

class ArcadeBuilding{
  constructor(x, y){
    this.x = x;
    this.y = y;
  }
  display(){
    fill(87, 24, 169)
    fill('hsla(308, 13%, 19%, 1)')
    //fill(126, 89, 166)
    noStroke()
    rect(this.x-200, this.y-200, 640, 400)
    
    
    //roof
    noStroke()
    fill(71, 28, 127)
    fill('hsla(308, 13%, 16%, 1)')
    triangle(this.x-250, this.y-200, this.x-150, this.y-200, this.x-150, this.y-300)
    rect(this.x-150, this.y-300, 530, 100)
    triangle(this.x+380, this.y-200, this.x+500, this.y-200, this.x+380, this.y-300)
    
    //banner
    noStroke()
    fill('hsba(160, 100%, 50%, 0.5)')
    rect(this.x-200, this.y-165,640, 70)
    rect(this.x-200, this.y-80,640, 70)
    fill('hsla(197, 27%, 50%, 1)')
    
    stroke('hsla(197, 27%, 50%, 1)')
    for(let i = 0; i<630; i+=100){
      line(this.x-170+i, this.y+200, this.x+i-170, this.y-180)
    }
    //text
    stroke(0)
    fill('red')
    textSize(70)
    strokeWeight(4)
    textFont(arcadeFont)
    //text("Nightmare at the Arcade", this.x-190, this.y-302)
    text("ARCADE", this.x-55, this.y-302)
    fill('blue')
    noStroke()
    rect(this.x-200, this.y-200, 640, 20)
    
    //door
    fill(0)
    stroke('brown')
    rect(this.x+40, this.y-80, 150, 500)
    fill('brown')
    stroke('brown')
    circle(this.x+160, this.y+10, 15)
    
    //closed
    fill('hsla(360, 87%, 37%, 1)')
    rect(this.x+70, this.y-100, 100, 50)
    textSize(30)
    stroke(0)
    strokeWeight(2)
    fill(0)
    textFont(normalFont)
    if(mouseX>=this.x+40 && mouseX<=this.x+190 && mouseY >=this.y-80 && this.y<=this.y-80+500){
    text('START!', this.x+77, this.y-65)
      if(mouseIsPressed&&timerButton3>30){
        gameScreen = 'chase'
      }
    }
    else{
      text('CLOSED!', this.x+70, this.y-65)
    }
    fill('yellow')
    stroke('yellow')
    circle(this.x+75, this.y-95, 3)
    circle(this.x+165, this.y-95, 3)
    circle(this.x+75, this.y-53, 3)
    circle(this.x+165, this.y-53, 3)
    
    //caution
    fill('yellow')
    strokeWeight(2)
    stroke(0)
    triangle(this.x-110, this.y-60, this.x-50, this.y-60, this.x-80, this.y-110)
    stroke(0)
    fill(0)
    textSize(45)
    text("!", this.x-92, this.y-65)
    
    //windows
    strokeWeight(5)
    stroke(255)
    fill(0)
    rect(this.x+270, this.y-150, 110, 90)
    line(this.x+325, this.y-150, this.x+325, this.y-60)
    line(this.x+270, this.y-105, this.x+380, this.y-105)
    
    
  }
  floor(){
    stroke(0)
    fill(125, 120, 110)
    rect(this.x-400, this.y+80,1000, 20)
  }
  lights(){
    
    if (frameCount % 60 == 0) { // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
    timer2 --;
  }
    if(timer2 %2 == 0){
      stroke('yellow')
      fill('yellow')
    }
    else{
      fill('red')
      stroke('red')
    }
    //stroke(250, 255, 80)
    for(let i = 0; i<640; i+=20){
      circle(this.x-190+i, this.y-190, 7)
    }
          //boards
    fill(196, 124, 0)
    stroke(196, 124, 0)
    push();
    angleMode (DEGREES);
    translate (this.x + 265, this.y - 105);
    rotate (345)
    rect(0, 0, 120, 30);
    angleMode (RADIANS);
    pop();
    fill('yellow')
    stroke('yellow')
  }
  startButton(){
    
  }
}

class Chase{
  constructor(x, y){
    this.x = x;
    this.y = y;
  }
  display(){
    background('purple')
    stroke('red')
    fill(0)
    textFont(introFont)
    textSize(90)
    strokeWeight(50) //100
    text("Nightmare at the Arcade", this.x-60, this.y-65)
  }
  button(){
    fill(172, 217, 255)
    strokeWeight(4)
    stroke('blue')
    if (mouseX>this.x+290&&mouseX<this.x+290+150&&mouseY>this.y+170&&mouseY<this.y+170+55&&timerButton1>30){
      fill(101, 166, 229);
      if (mouseIsPressed){
        gameScreen = "forestStoryline"
      }
    }
    rect(this.x+290, this.y+170, 150, 55)
    textSize(38)
    textFont(normalFont)
    stroke(0)
    fill(0)
    strokeWeight(2)
    text('START', this.x+315, this.y+210)
    noStroke()
    //add code to make button go to next screen 
  }
  textBox(){
    fill('white')
    // ellipse(this.x+30, this.y+50, 100, 70)
    ellipse(this.x+40, this.y+30, 190, 110)
    triangle(this.x-10, this.y+60, this.x, this.y+60, this.x-20, this.y+100)
  }
}

class Collision{
  constructor(){
    
  }
  check(){
     for(let i = 0; i<zombiesRight.length; i++){
  if(dist(mouseX, mouseY, zombiesRight[i].zombieX+10, zombiesRight[i].zombieY+30)<20){
    if(mouseIsPressed){
      zombiesRight.splice(i, 1)
      scoreNum++;
    }
  }
     }
    for(let i = 0; i<zombiesLeft.length; i++){
  if(dist(mouseX, mouseY, zombiesLeft[i].zombieX+10, zombiesLeft[i].zombieY+30)<30){
    if(mouseIsPressed){
      zombiesLeft.splice(i, 1)
      scoreNum++;
    }
  }
  } 
  }
}

class NextButton{
  constructor(x, y){
    this.x = x;
    this.y = y;
  }
  display(){
    strokeWeight(3)
  stroke(7, 150, 212)
  fill(40, 255, 205)
    
  if(mouseX>=this.x+230 && mouseX<=this.x+380 && mouseY>=this.y-75 && mouseY<=this.y-20){
    fill(255,255, 180)
    if(mouseIsPressed){
      gameScreen = "instructionsSpace";
    }
  }
  rect(this.x+230, this.y-75, 150, 55)
  
  textSize(40)
  fill(7, 150, 212)
  stroke('blue')
  text('Next...', this.x+240, this.y-35)
  }
}

function drawRipple(ripple){
  strokeWeight(5);
  stroke(51, 167, 255);    
  line(ripple.x, ripple.y, ripple.x+ripple.z,ripple.y);
  noStroke();
}

function play2() {
  if (!song.isPlaying()) {
    song.loop();

  } else {
    song.pause();

  }
}